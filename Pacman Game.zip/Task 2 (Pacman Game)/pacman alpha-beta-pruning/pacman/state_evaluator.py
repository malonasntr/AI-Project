# state_evaluator.py
# Kelas untuk mengevaluasi kualitas suatu state game Pacman (versi yang ditingkatkan)

class StateEvaluator:
    def __init__(self, level, ghosts, game):
        self.level = level
        self.ghosts = ghosts
        self.game = game
        
        # Parameter bobot untuk evaluasi - meningkatkan prioritas pelet
        self.weights = {
            'pellet_distance': 100.0,         # ⬆️ Meningkatkan prioritas pelet terdekat
            'power_pellet_distance': 35.0,    # ⬆️ Meningkatkan prioritas power pellet
            'ghost_distance': 15.0,           # ⬇️ Menurunkan prioritas hantu kecuali sangat dekat
            'ghost_vulnerability': 50.0,      # Nilai hantu rentan
            'pellet_density': 90.0,           # ⬆️ Meningkatkan prioritas area dengan banyak pelet
            'corner_penalty': 15.0,           # Penalti untuk posisi pojok
            'dead_end_penalty': 40.0,         # Penalti untuk jalan buntu
            'exploration_bonus': 15.0,        # ⬆️ Meningkatkan bonus eksplorasi
            'path_length': 5.0,               # ⬆️ Meningkatkan nilai jalur yang panjang
            'direction_persistence': 8.0      # 🆕 Nilai baru untuk jaga arah konsisten
        }
        
        # Cache untuk perhitungan yang mahal
        self.dead_end_cache = {}
        self.corner_cache = {}
        self.path_length_cache = {}
        self.last_direction = (0, 0)  # Untuk konsistensi arah
        
    def evaluate(self, x, y, velX, velY, weights=None):
        """
        Evaluasi menyeluruh suatu state game
        
        Parameters:
        -----------
        x, y: posisi Pacman
        velX, velY: kecepatan Pacman
        weights: dictionary bobot opsional untuk menyesuaikan evaluasi
        
        Returns:
        --------
        score: nilai keseluruhan state game
        """
        score = 0.0
        
        # Gunakan weights jika disediakan, jika tidak gunakan self.weights default
        w = weights if weights else self.weights
        
        # 1. Jarak ke pelet terdekat (semakin dekat semakin baik)
        pellet_distance = self.find_nearest_pellet_distance(x, y)
        if pellet_distance > 0:
            score += w.get('pellet_distance', self.weights['pellet_distance']) * (100.0 / pellet_distance)
        else:
            # Jika tidak ada pelet terdekat yang ditemukan, berikan penalti
            score -= 500
        
        # 2. Jarak dan keadaan hantu
        ghost_score = self.evaluate_ghosts(x, y, weights)
        score += ghost_score
        
        # 3. Kepadatan pelet di sekitar
        pellet_density = self.calculate_pellet_density(x, y, 5)
        score += w.get('pellet_density', self.weights['pellet_density']) * pellet_density
        
        # 4. Jarak ke power pellet
        power_pellet_distance = self.find_nearest_power_pellet_distance(x, y)
        if power_pellet_distance > 0:
            # Nilai power pellet lebih tinggi jika ada hantu di dekat
            ghost_nearby = False
            for i in range(0, 4):
                ghost = self.ghosts.get(i)
                if ghost and ghost.state == 1:  # Normal ghost
                    distance = abs(x - ghost.x) + abs(y - ghost.y)
                    if distance < 80:
                        ghost_nearby = True
                        break
            
            if ghost_nearby:
                score += w.get('power_pellet_distance', self.weights['power_pellet_distance']) * (150.0 / power_pellet_distance)
            else:
                score += w.get('power_pellet_distance', self.weights['power_pellet_distance']) * (100.0 / power_pellet_distance)
        
        # 5. Penalti untuk pojok dan jalan buntu
        is_corner = self.is_corner(x, y)
        if is_corner:
            score -= w.get('corner_penalty', self.weights['corner_penalty'])
            
        is_dead_end = self.is_dead_end(x, y)
        if is_dead_end:
            score -= w.get('dead_end_penalty', self.weights['dead_end_penalty'])
        
        # 6. Nilai buah - DINONAKTIFKAN (karena thisFruit tidak tersedia)
        # fruit_score = self.evaluate_fruit(x, y)
        # score += fruit_score
        
        # 7. Bonus eksplorasi
        exploration_bonus = self.calculate_exploration_bonus(x, y, velX, velY)
        score += w.get('exploration_bonus', self.weights['exploration_bonus']) * exploration_bonus
        
        # 8. Nilai jalur yang panjang
        path_length = self.calculate_path_length(x, y, velX, velY)
        score += w.get('path_length', self.weights['path_length']) * path_length * 2  # Dikalikan 2
        
        # 9. Konsistensi arah
        direction_persistence = self.calculate_direction_persistence(velX, velY)
        score += w.get('direction_persistence', self.weights['direction_persistence']) * direction_persistence
        
        # Update arah terakhir
        if velX != 0 or velY != 0:
            self.last_direction = (velX, velY)
        
        return score
    
    # Tambahkan method ini ke dalam kelas StateEvaluator
    def calculate_direction_persistence(self, velX, velY):
        """
        Hitung nilai untuk tetap pada arah yang sama
        Ini akan mendorong Pacman untuk bergerak dalam satu arah dan menghindari bolak-balik
        """
        # Inisialisasi last_direction jika belum ada
        if not hasattr(self, 'last_direction'):
            self.last_direction = (0, 0)
        
        # Jika arah sama dengan arah terakhir, beri nilai tinggi
        if (velX, velY) == self.last_direction and (velX != 0 or velY != 0):
            return 10.0
        
        # Jika arah berubah 90 derajat, beri nilai medium
        if (velX != 0 and self.last_direction[1] != 0) or (velY != 0 and self.last_direction[0] != 0):
            return 5.0
            
        # Jika arah berlawanan, beri nilai negatif
        if (velX == -self.last_direction[0] and velX != 0) or (velY == -self.last_direction[1] and velY != 0):
            return -10.0
            
        return 0.0

    def evaluate_ghosts(self, x, y, weights=None):
        """Evaluasi posisi hantu relatif terhadap Pacman"""
        score = 0
        
        # Gunakan weights jika disediakan
        w = weights if weights else self.weights
        
        for i in range(0, 4):
            ghost = self.ghosts.get(i)
            if not ghost:
                continue
                
            distance = abs(x - ghost.x) + abs(y - ghost.y)
            
            if ghost.state == 1:  # Hantu normal
                # Penalti jarak berbasis eksponensial (semakin dekat semakin berbahaya)
                if distance < 32:  # Zona bahaya tinggi
                    score -= w.get('ghost_distance', self.weights['ghost_distance']) * (8000 / max(distance, 1))
                elif distance < 64:  # Zona hati-hati
                    score -= w.get('ghost_distance', self.weights['ghost_distance']) * (2000 / max(distance, 1))
                else:
                    # Hantu jauh, hanya beri penalti kecil
                    score -= w.get('ghost_distance', self.weights['ghost_distance']) * 50
            
            elif ghost.state == 2:  # Hantu rentan
                # Bonus untuk hantu rentan yang dekat
                if distance < 64:
                    score += w.get('ghost_vulnerability', self.weights['ghost_vulnerability']) * (64 / max(distance, 1))
                elif distance < 128:
                    score += w.get('ghost_vulnerability', self.weights['ghost_vulnerability']) * (32 / max(distance, 1))
                    
                # Pertimbangkan waktu rentan yang tersisa
                if self.game.ghostTimer < 60:  # Jika waktu hampir habis
                    score *= (self.game.ghostTimer / 60)
        
        return score
    
    def find_nearest_pellet_distance(self, x, y):
        """Temukan jarak ke pelet terdekat - radius pencarian diperbesar"""
        min_distance = float('inf')
        row = int((y + 8) / 16)
        col = int((x + 8) / 16)
        
        # Cari dalam radius 15 tile (diperbesar dari 10)
        for i in range(row-15, row+16):
            for j in range(col-15, col+16):
                if i >= 0 and i < self.level.lvlHeight and j >= 0 and j < self.level.lvlWidth:
                    if self.level.GetMapTile(i, j) == 2:  # Pellet
                        distance = abs(i - row) + abs(j - col)  # Manhattan distance
                        min_distance = min(min_distance, distance)
        
        if min_distance == float('inf'):
            return 0
        return min_distance
    
    def find_nearest_power_pellet_distance(self, x, y):
        """Temukan jarak ke power pellet terdekat"""
        min_distance = float('inf')
        row = int((y + 8) / 16)
        col = int((x + 8) / 16)
        
        for i in range(0, self.level.lvlHeight):
            for j in range(0, self.level.lvlWidth):
                if self.level.GetMapTile(i, j) == 3:  # Power Pellet
                    distance = abs(i - row) + abs(j - col)
                    min_distance = min(min_distance, distance)
        
        if min_distance == float('inf'):
            return 0
        return min_distance
    
    def calculate_pellet_density(self, x, y, radius):
        """Hitung kepadatan pelet di sekitar suatu posisi"""
        pellet_count = 0
        total_tiles = 0
        row = int((y + 8) / 16)
        col = int((x + 8) / 16)
        
        for i in range(row-radius, row+radius+1):
            for j in range(col-radius, col+radius+1):
                if i >= 0 and i < self.level.lvlHeight and j >= 0 and j < self.level.lvlWidth:
                    total_tiles += 1
                    if self.level.GetMapTile(i, j) == 2:  # Pellet
                        pellet_count += 1
        
        if total_tiles == 0:
            return 0
        
        return (pellet_count / total_tiles) * 100
    
    def is_corner(self, x, y):
        """Cek apakah posisi merupakan pojok (dikelilingi dinding)"""
        # Cek cache
        key = (x, y)
        if key in self.corner_cache:
            return self.corner_cache[key]
        
        row = int((y + 8) / 16)
        col = int((x + 8) / 16)
        
        # Hitung jumlah dinding di sekitar
        wall_count = 0
        open_directions = 0
        
        # Cek 4 arah (atas, bawah, kiri, kanan)
        if self.level.IsWall(row-1, col):  # Atas
            wall_count += 1
        else:
            open_directions += 1
            
        if self.level.IsWall(row+1, col):  # Bawah
            wall_count += 1
        else:
            open_directions += 1
            
        if self.level.IsWall(row, col-1):  # Kiri
            wall_count += 1
        else:
            open_directions += 1
            
        if self.level.IsWall(row, col+1):  # Kanan
            wall_count += 1
        else:
            open_directions += 1
        
        # Jika hanya ada 1 arah terbuka, ini adalah pojok
        result = (open_directions == 1)
        self.corner_cache[key] = result
        return result
    
    def is_dead_end(self, x, y):
        """Cek apakah posisi merupakan jalan buntu"""
        # Cek cache
        key = (x, y)
        if key in self.dead_end_cache:
            return self.dead_end_cache[key]
        
        row = int((y + 8) / 16)
        col = int((x + 8) / 16)
        
        # Hitung jumlah arah terbuka
        open_directions = 0
        
        # Cek 4 arah (atas, bawah, kiri, kanan)
        if not self.level.IsWall(row-1, col):  # Atas
            open_directions += 1
            
        if not self.level.IsWall(row+1, col):  # Bawah
            open_directions += 1
            
        if not self.level.IsWall(row, col-1):  # Kiri
            open_directions += 1
            
        if not self.level.IsWall(row, col+1):  # Kanan
            open_directions += 1
        
        # Jika hanya ada 1 arah terbuka, ini adalah jalan buntu
        result = (open_directions == 1)
        self.dead_end_cache[key] = result
        return result
    
    def calculate_exploration_bonus(self, x, y, velX, velY):
        """Hitung bonus untuk menjelajahi area baru - algoritma yang ditingkatkan"""
        # Implementasi yang lebih agresif: berikan bonus lebih tinggi jika bergerak ke arah dengan pelet
        row = int((y + 8) / 16)
        col = int((x + 8) / 16)
        
        # Prediksi posisi berikutnya
        next_row = int(((y + velY * 5) + 8) / 16)
        next_col = int(((x + velX * 5) + 8) / 16)
        
        current_pellets = 0
        next_pellets = 0
        
        # Hitung pelet di sekitar posisi saat ini dengan radius lebih besar
        for i in range(row-5, row+6):
            for j in range(col-5, col+6):
                if i >= 0 and i < self.level.lvlHeight and j >= 0 and j < self.level.lvlWidth:
                    if self.level.GetMapTile(i, j) == 2:  # Pellet
                        current_pellets += 1
        
        # Hitung pelet di sekitar posisi berikutnya dengan radius lebih besar
        for i in range(next_row-5, next_row+6):
            for j in range(next_col-5, next_col+6):
                if i >= 0 and i < self.level.lvlHeight and j >= 0 and j < self.level.lvlWidth:
                    if self.level.GetMapTile(i, j) == 2:  # Pellet
                        next_pellets += 1
        
        # Bonus yang lebih tinggi jika posisi berikutnya memiliki lebih banyak pelet
        if next_pellets > current_pellets:
            return (next_pellets - current_pellets) * 3  # Dikalikan 3
        elif next_pellets == current_pellets:
            return 1  # Tetap berikan sedikit bonus untuk eksplorasi
        else:
            return 0
    
    def calculate_path_length(self, x, y, velX, velY):
        """Hitung panjang jalur yang dapat dilalui tanpa menabrak dinding"""
        # Cek cache
        key = (x, y, velX, velY)
        if key in self.path_length_cache:
            return self.path_length_cache[key]
        
        length = 0
        cur_x = x
        cur_y = y
        
        while True:
            # Prediksi posisi berikutnya
            next_x = cur_x + velX
            next_y = cur_y + velY
            
            # Cek apakah menabrak dinding
            if self.level.CheckIfHitWall(next_x, next_y, int((cur_y + 8) / 16), int((cur_x + 8) / 16)):
                break
            
            cur_x = next_x
            cur_y = next_y
            length += 1
            
            # Batasi panjang pencarian
            if length >= 20:
                break
        
        self.path_length_cache[key] = length
        return length
    
    def calculate_direction_persistence(self, velX, velY):
        """
        Baru: Hitung nilai untuk tetap pada arah yang sama
        Ini akan mendorong Pacman untuk bergerak dalam satu arah dan menghindari bolak-balik
        """
        # Jika arah sama dengan arah terakhir, beri nilai tinggi
        if (velX, velY) == self.last_direction and (velX != 0 or velY != 0):
            return 10.0
        
        # Jika arah berubah 90 derajat, beri nilai medium
        if (velX != 0 and self.last_direction[1] != 0) or (velY != 0 and self.last_direction[0] != 0):
            return 5.0
            
        # Jika arah berlawanan, beri nilai negatif
        if (velX == -self.last_direction[0] and velX != 0) or (velY == -self.last_direction[1] and velY != 0):
            return -10.0
            
        return 0.0