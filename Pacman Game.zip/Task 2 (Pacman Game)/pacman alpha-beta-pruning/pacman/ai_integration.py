# ai_integration.py
# File untuk mengintegrasikan AI controller ke dalam game Pacman

import pygame

from enhanced_ab_controller import EnhancedAlphaBetaController
from state_evaluator import StateEvaluator
from game_state_simulator import GameStateSimulator

class AIIntegrator:
    def __init__(self, player, level, ghosts, game):
        self.player = player
        self.level = level
        self.ghosts = ghosts
        self.game = game
        
        # Inisialisasi komponen AI
        self.evaluator = StateEvaluator(level, ghosts, game)
        self.simulator = GameStateSimulator(player, level, ghosts, game)
        
        # Inisialisasi controller
        self.alpha_beta_controller = EnhancedAlphaBetaController(player, level, ghosts, game)
        
        # Mode AI saat ini
        # 0: Manual control
        # 1: Alpha-Beta Pruning
        self.current_mode = 1  # Default ke Alpha-Beta Pruning
        
        # Informasi debug
        self.debug_info = {
            'mode': 'Alpha-Beta Pruning',
            'last_move': 'NONE',
            'score': 0,
            'ghost_distances': []
        }
        
        # Simpan status tombol toggle sebelumnya
        self.prev_toggle = False
    
    def toggle_mode(self):
        """Beralih antara mode AI yang berbeda"""
        self.current_mode = (self.current_mode + 1) % 2
        
        if self.current_mode == 0:
            self.debug_info['mode'] = 'Manual Control'
        elif self.current_mode == 1:
            self.debug_info['mode'] = 'Alpha-Beta Pruning'
    
    def get_next_move(self):
        """Mendapatkan gerakan berikutnya dari controller yang aktif"""
        # Update informasi debug
        self.debug_info['score'] = self.game.score
        self.debug_info['ghost_distances'] = [
            (i, abs(self.player.x - ghost.x) + abs(self.player.y - ghost.y))
            for i, ghost in self.ghosts.items() if i < 4
        ]
        
        # Kembalikan manual control jika mode 0
        if self.current_mode == 0:
            return None
        
        # Gunakan Alpha-Beta Pruning
        elif self.current_mode == 1:
            move = self.alpha_beta_controller.get_next_move()
            self.debug_info['last_move'] = move
            return move
    
    def get_debug_info(self):
        """Mendapatkan informasi debug untuk ditampilkan"""
        return self.debug_info

    def check_inputs(self, game_ref, player_ref, level_ref, js_ref=None, JS_XAXIS=0, JS_YAXIS=1, JS_STARTBUTTON=0):
        """
        Metode yang menggantikan CheckInputs() di kode utama
        """
        # Cek apakah tombol mode AI ditekan (t)
        keys = pygame.key.get_pressed()
        toggle_pressed = keys[pygame.K_t]
        
        # Hanya toggle jika tombol baru ditekan (tidak terus menerus)
        if toggle_pressed and not self.prev_toggle:
            self.toggle_mode()
        
        self.prev_toggle = toggle_pressed
        
        # Jika dalam mode manual, biarkan input original
        if self.current_mode == 0:
            # Kode asli dari CheckInputs()
            if game_ref.mode == 1:
                if keys[pygame.K_RIGHT] or (js_ref is not None and js_ref.get_axis(JS_XAXIS) > 0):
                    if not level_ref.CheckIfHitWall(player_ref.x + player_ref.speed, player_ref.y, player_ref.nearestRow, player_ref.nearestCol): 
                        player_ref.velX = player_ref.speed
                        player_ref.velY = 0
                        
                elif keys[pygame.K_LEFT] or (js_ref is not None and js_ref.get_axis(JS_XAXIS) < 0):
                    if not level_ref.CheckIfHitWall(player_ref.x - player_ref.speed, player_ref.y, player_ref.nearestRow, player_ref.nearestCol): 
                        player_ref.velX = -player_ref.speed
                        player_ref.velY = 0
                    
                elif keys[pygame.K_DOWN] or (js_ref is not None and js_ref.get_axis(JS_YAXIS) > 0):
                    if not level_ref.CheckIfHitWall(player_ref.x, player_ref.y + player_ref.speed, player_ref.nearestRow, player_ref.nearestCol): 
                        player_ref.velX = 0
                        player_ref.velY = player_ref.speed
                    
                elif keys[pygame.K_UP] or (js_ref is not None and js_ref.get_axis(JS_YAXIS) < 0):
                    if not level_ref.CheckIfHitWall(player_ref.x, player_ref.y - player_ref.speed, player_ref.nearestRow, player_ref.nearestCol):
                        player_ref.velX = 0
                        player_ref.velY = -player_ref.speed
        else:
            # Gunakan AI controller
            if game_ref.mode == 1:
                self.get_next_move()
        
        # Kode umum yang selalu dijalankan
        if keys[pygame.K_ESCAPE]:
            import sys
            sys.exit(0)
                
        elif game_ref.mode == 3:
            if keys[pygame.K_RETURN] or (js_ref is not None and js_ref.get_button(JS_STARTBUTTON)):
                game_ref.StartNewGame()

# Fungsi untuk menyiapkan integrasi AI dengan game utama
def setup_ai_integration(player, level, ghosts, game):
    """Membuat dan mengembalikan objek AIIntegrator"""
    return AIIntegrator(player, level, ghosts, game)

# Fungsi untuk menggambar informasi AI di layar
def draw_ai_info(ai_integrator, screen):
    """Menggambar informasi debug AI di layar"""
    # Hanya gambar jika mode AI aktif
    if ai_integrator.current_mode > 0:
        font = pygame.font.Font(None, 24)
        
        # Mode AI
        text = font.render("AI Mode: " + ai_integrator.debug_info['mode'], True, (255, 255, 0))
        screen.blit(text, (10, 10))