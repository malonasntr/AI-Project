# advanced_ab_controller.py
# Implementasi AI Controller canggih untuk Pacman dengan algoritma Alpha-Beta Pruning
# dan strategi gameplay yang ditingkatkan

from state_evaluator import StateEvaluator
from game_state_simulator import GameStateSimulator
import random
import time

class EnhancedAlphaBetaController:
    def __init__(self, player, level, ghosts, game):
        self.player = player
        self.level = level
        self.ghosts = ghosts
        self.game = game
        self.evaluator = StateEvaluator(level, ghosts, game)
        self.simulator = GameStateSimulator(player, level, ghosts, game)
        
        # Kemungkinan arah gerakan
        self.directions = {
            "RIGHT": (self.player.speed, 0),
            "LEFT": (-self.player.speed, 0),
            "DOWN": (0, self.player.speed),
            "UP": (0, -self.player.speed),
            "STOP": (0, 0)
        }
        
        # Parameter algoritma
        self.max_depth = 4  # Kedalaman pencarian dasar
        self.adaptive_depth = True  # Kedalaman dinamis berdasarkan situasi
        self.last_move = "STOP"
        self.opposite_moves = {
            "RIGHT": "LEFT",
            "LEFT": "RIGHT",
            "UP": "DOWN",
            "DOWN": "UP"
        }
        
        # Cache
        self.transposition_table = {}
        self.cache_lifetime = 50  # Reset cache setelah 50 gerakan
        self.move_counter = 0
        
        # Riwayat untuk deteksi pola
        self.position_history = []  # [(x, y), ...]
        self.position_history_max = 30
        self.move_history = []  # ["UP", "RIGHT", ...]
        self.move_history_max = 20
        self.tile_visit_counts = {}  # {(row, col): visit_count}
        
        # Penanganan stuck
        self.stuck_counter = 0
        self.oscillation_counter = 0
        self.last_positions = [(0, 0)] * 10  # Last 10 positions
        self.breakout_mode = False
        self.breakout_target = None
        self.breakout_timer = 0
        self.breakout_duration = 15
        
        # Target dan mode permainan
        self.hunting_target = None  # Target saat mode hunting
        self.prev_pellet_count = level.pellets  # Untuk pelacakan pelet yang dimakan
        self.visited_pellets = set()  # Untuk menghindari lingkaran
        
        # Mode permainan:
        # 0: Normal - Seimbang antara makan pelet dan hindari hantu
        # 1: Hunt - Aktif mencari pelet ketika aman
        # 2: Escape - Prioritaskan keselamatan saat hantu dekat
        # 3: Power - Kejar hantu saat power pellet aktif
        # 4: Breakout - Keluar dari pola berulang
        # 5: Sweep - Bersihkan area tertentu
        self.game_mode = 0
        self.mode_timer = 0
        
        # Buat peta labirin untuk pathfinding yang lebih cepat
        self.build_maze_map()
        
        # Deteksi area penumpukan pelet
        self.pellet_clusters = self.find_pellet_clusters()
        
        # Waktu terakhir arah diubah
        self.last_direction_change = time.time()
        
    def get_next_move(self):
        """Menentukan gerakan terbaik berikutnya"""
        self.move_counter += 1
        
        # Reset cache secara berkala
        if self.move_counter >= self.cache_lifetime:
            self.transposition_table = {}
            self.move_counter = 0
        
        # Catat posisi untuk deteksi pola
        current_pos = (self.player.x, self.player.y)
        self.position_history.append(current_pos)
        if len(self.position_history) > self.position_history_max:
            self.position_history.pop(0)
            
        # Update tile visit counts
        current_tile = (self.player.nearestRow, self.player.nearestCol)
        self.tile_visit_counts[current_tile] = self.tile_visit_counts.get(current_tile, 0) + 1
        
        # Update last positions array for oscillation detection
        self.last_positions.pop(0)
        self.last_positions.append(current_pos)
        
        # Deteksi perubahan jumlah pelet (pelet dimakan)
        if self.prev_pellet_count > self.level.pellets:
            self.visited_pellets.add(current_tile)
            self.prev_pellet_count = self.level.pellets
            
            # Jika pelet dimakan, refresh pellet clusters
            if len(self.visited_pellets) % 10 == 0:  # Setiap 10 pelet
                self.pellet_clusters = self.find_pellet_clusters()
        
        # ===== MODE SELECTION LOGIC =====
        self.update_game_mode()
        
        # ===== BREAKOUT MODE PROCESSING =====
        if self.game_mode == 4:  # Breakout mode
            return self.process_breakout_mode()
            
        # ===== NORMAL, HUNT, ESCAPE, POWER MODE PROCESSING =====
        
        # Jika power pellet aktif (mode 3)
        if self.game_mode == 3:
            # Cari hantu vulnerabel terdekat
            ghost_dir = self.hunt_vulnerable_ghosts()
            if ghost_dir:
                self.update_move_history(ghost_dir)
                return self.apply_move(ghost_dir)
                
        # Jika dalam mode escape (prioritas keselamatan)
        if self.game_mode == 2:
            safe_dir = self.find_safe_escape_route()
            if safe_dir:
                self.update_move_history(safe_dir)
                return self.apply_move(safe_dir)
                
        # Untuk mode hunt/sweep (cari dan makan pelet)
        if self.game_mode == 1 or self.game_mode == 5:
            # Tentukan target huntin jika belum ada atau sudah tercapai
            if self.hunting_target is None or self.is_near_target(self.hunting_target, 16):
                self.hunting_target = self.select_next_hunting_target()
            
            # Move towards the target
            if self.hunting_target:
                target_dir = self.move_towards_target(self.hunting_target[0], self.hunting_target[1])
                if target_dir:
                    self.update_move_history(target_dir)
                    return self.apply_move(target_dir)
        
        # Jika sampai di sini, gunakan alpha-beta pruning standar
        # Tetapi dengan kemampuan pencegahan oscillasi
        
        # Deteksi oscillasi (gerakan berulang)
        is_oscillating = self.detect_oscillation()
        if is_oscillating:
            self.oscillation_counter += 1
            
            # Jika oscillasi terdeteksi terus-menerus, aktifkan mode breakout
            if self.oscillation_counter >= 3:
                self.activate_breakout_mode()
                return self.process_breakout_mode()
        else:
            self.oscillation_counter = 0
            
        # Regular Alpha-Beta search with oscillation prevention
        best_move = self.find_best_move(is_oscillating)
        
        # Track the move
        self.update_move_history(best_move)
        
        # Apply the selected move
        return self.apply_move(best_move)
        
    def update_game_mode(self):
        """Update mode permainan berdasarkan kondisi saat ini"""
        # Default to normal mode
        prev_mode = self.game_mode
        self.game_mode = 0
        
        # Mode 4 - Breakout mode
        if self.breakout_mode:
            self.game_mode = 4
            self.breakout_timer -= 1
            if self.breakout_timer <= 0:
                self.breakout_mode = False
                self.breakout_target = None
            return
            
        # Mode 3 - Power mode (hantu dapat dimakan)
        if self.game.ghostTimer > 0:
            vulnerable_nearby = False
            for i in range(0, 4):
                ghost = self.ghosts.get(i)
                if ghost and ghost.state == 2:  # Vulnerable ghost
                    distance = abs(self.player.x - ghost.x) + abs(self.player.y - ghost.y)
                    if distance < 120:  # Cukup dekat untuk dikejar
                        vulnerable_nearby = True
                        break
            
            if vulnerable_nearby:
                self.game_mode = 3
                return
                
        # Mode 2 - Escape mode (hantu dekat)
        ghost_threat = self.calculate_ghost_threat()
        if ghost_threat > 60:  # Tingkat ancaman tinggi
            self.game_mode = 2
            return
            
        # Mode 1 - Hunt mode (cari pelet)
        if ghost_threat < 30:  # Situasi relatif aman
            self.game_mode = 1
            return
            
        # Mode 5 - Sweep mode (bersihkan area)
        if self.level.pellets < 30 and ghost_threat < 40:  # Pelet tinggal sedikit dan cukup aman
            self.game_mode = 5
            return
            
        # Jika mode berubah, reset timer
        if prev_mode != self.game_mode:
            self.mode_timer = 0
        else:
            self.mode_timer += 1
    
    def calculate_ghost_threat(self):
        """Hitung tingkat ancaman dari hantu-hantu di sekitar"""
        threat_level = 0
        
        for i in range(0, 4):
            ghost = self.ghosts.get(i)
            if ghost and ghost.state == 1:  # Normal ghost
                distance = abs(self.player.x - ghost.x) + abs(self.player.y - ghost.y)
                
                # Semakin dekat, semakin mengancam
                if distance < 32:
                    threat_level += 100
                elif distance < 64:
                    threat_level += 60
                elif distance < 96:
                    threat_level += 30
                elif distance < 128:
                    threat_level += 10
                    
        return threat_level
        
    def find_best_move(self, is_oscillating=None):
        """Gunakan alpha-beta pruning untuk mencari gerakan terbaik"""
        best_move = "STOP"
        best_score = float('-inf')
        alpha = float('-inf')
        beta = float('inf')
        
        # Kedalaman adaptif berdasarkan mode dan situasi
        depth = self.max_depth
        if self.adaptive_depth:
            if self.game_mode == 2:  # Escape mode - kedalaman lebih rendah untuk respons cepat
                depth = 3
            elif self.game_mode == 1:  # Hunt mode - kedalaman lebih tinggi untuk strategi lebih baik
                depth = 5
                
        # Weights untuk evaluasi berdasarkan mode
        weights = {}
        if self.game_mode == 1:  # Hunt mode - fokus pada pelet
            weights = {
                'pellet_distance': 3.0,  # Tingkatkan prioritas pelet
                'ghost_distance': 0.7  # Kurangi pengaruh hantu
            }
        elif self.game_mode == 2:  # Escape mode - fokus pada keselamatan
            weights = {
                'pellet_distance': 0.5,  # Kurangi prioritas pelet
                'ghost_distance': 3.0  # Tingkatkan prioritas hantu
            }
            
        # Evaluasi setiap arah yang mungkin
        for direction, (velX, velY) in self.directions.items():
            if direction == "STOP":
                continue
                
            # Skip opposite direction to avoid 180 degree turns unless necessary
            if direction == self.opposite_moves.get(self.last_move, None) and self.last_move != "STOP":
                continue
                
            # Jika terdeteksi osilasi, hindari arah yang terlibat
            if is_oscillating and direction in is_oscillating:
                continue
                
            # Cek apakah gerakan valid (tidak nabrak tembok)
            if not self.level.CheckIfHitWall(
                self.player.x + velX, 
                self.player.y + velY, 
                self.player.nearestRow, 
                self.player.nearestCol
            ):
                # Posisi baru setelah gerakan
                new_x = self.player.x + velX
                new_y = self.player.y + velY
                new_tile = (int((new_y + 8) / 16), int((new_x + 8) / 16))
                
                # Kurangi skor jika tile sudah sering dikunjungi
                visit_penalty = min(self.tile_visit_counts.get(new_tile, 0) * 20, 200)
                
                # Gunakan cache jika ada
                state_key = (new_x, new_y, velX, velY, depth, self.game_mode)
                if state_key in self.transposition_table:
                    score = self.transposition_table[state_key]
                else:
                    # Alpha-beta search
                    score = self.alpha_beta_min_max(
                        new_x, new_y, velX, velY, 
                        1, depth, alpha, beta, True, weights
                    )
                    self.transposition_table[state_key] = score
                
                # Adjust score based on various factors
                
                # Penalti untuk arah berlawanan
                if direction == self.opposite_moves.get(self.last_move, None):
                    score *= 0.3  # Penalti besar untuk gerakan bolak-balik
                
                # Penalti untuk tile yang sering dikunjungi
                score -= visit_penalty
                
                # Bonus untuk gerakan yang jarang dilakukan
                novelty_bonus = self.calculate_novelty_bonus(direction) * 150
                score += novelty_bonus
                
                # Bonus untuk pelet/power pelet di tile tujuan
                if self.level.GetMapTile(new_tile[0], new_tile[1]) == 2:  # Pelet
                    score += 200
                elif self.level.GetMapTile(new_tile[0], new_tile[1]) == 3:  # Power pelet
                    score += 400
                
                # Update hasil terbaik
                if score > best_score:
                    best_score = score
                    best_move = direction
                    
                alpha = max(alpha, best_score)
        
        # Jika tidak ada gerakan yang valid, coba opsi lain termasuk gerakan berlawanan
        if best_move == "STOP":
            for direction, (velX, velY) in self.directions.items():
                if direction == "STOP":
                    continue
                    
                if not self.level.CheckIfHitWall(
                    self.player.x + velX, 
                    self.player.y + velY, 
                    self.player.nearestRow, 
                    self.player.nearestCol
                ):
                    return direction
        
        return best_move
        
    def alpha_beta_min_max(self, x, y, velX, velY, current_depth, max_depth, alpha, beta, is_max_player, weights=None):
        """Alpha-Beta Pruning dengan evaluasi yang lebih baik"""
        # Cache check
        state_key = (x, y, velX, velY, current_depth, max_depth, is_max_player)
        if state_key in self.transposition_table:
            return self.transposition_table[state_key]
            
        # Base case
        if current_depth == max_depth or self.is_terminal_state(x, y):
            score = self.evaluator.evaluate(x, y, velX, velY, weights)
            self.transposition_table[state_key] = score
            return score
            
        # Maximizer (Pacman)
        if is_max_player:
            value = float('-inf')
            
            # Explore possible moves
            for direction, (dx, dy) in self.directions.items():
                if direction == "STOP":
                    continue
                    
                new_x = x + dx
                new_y = y + dy
                
                # Check if valid move
                if not self.level.CheckIfHitWall(new_x, new_y, int((y + 8) / 16), int((x + 8) / 16)):
                    # Simulate move
                    sim_x, sim_y, points, hit_ghost, ghost_state = self.simulator.simulate_pacman_move(
                        new_x, new_y, dx, dy, 1
                    )
                    
                    # Handle ghost collision
                    if hit_ghost:
                        if ghost_state == 1:  # Normal ghost
                            temp_value = -20000  # Big penalty
                        else:  # Vulnerable ghost
                            temp_value = 1000 + self.alpha_beta_min_max(
                                sim_x, sim_y, dx, dy,
                                current_depth + 1, max_depth,
                                alpha, beta, False, weights
                            )
                    else:
                        # Recurse - next level is minimizer (ghosts)
                        temp_value = self.alpha_beta_min_max(
                            sim_x, sim_y, dx, dy,
                            current_depth + 1, max_depth,
                            alpha, beta, False, weights
                        )
                        
                    # Add points gained
                    temp_value += points * 10  # Boost point value
                    
                    value = max(value, temp_value)
                    alpha = max(alpha, value)
                    
                    if beta <= alpha:
                        break  # Beta cutoff
            
            self.transposition_table[state_key] = value
            return value
            
        # Minimizer (Ghosts)
        else:
            value = float('inf')
            
            # Simulate ghost paths
            ghost_paths = self.simulator.simulate_ghost_paths(x, y, 3)  # Increased look-ahead
            
            # Check collisions with ghosts
            collision_penalty = 0
            
            for ghost_id, path in ghost_paths.items():
                if len(path) >= 2:  # Ensure there's movement after initial position
                    for step in range(1, min(3, len(path))):  # Check multiple steps ahead
                        ghost_pos = path[step]
                        distance = abs(x - ghost_pos[0]) + abs(y - ghost_pos[1])
                        
                        # Collision danger increases as ghost gets closer
                        if distance < 16:  # Very close - likely collision
                            ghost = self.ghosts.get(ghost_id)
                            if ghost and ghost.state == 1:  # Normal ghost
                                collision_penalty = max(collision_penalty, 15000)
                            elif ghost and ghost.state == 2:  # Vulnerable ghost
                                collision_penalty = min(collision_penalty, -750)  # Bonus
                        elif distance < 32:  # Close
                            ghost = self.ghosts.get(ghost_id)
                            if ghost and ghost.state == 1:
                                collision_penalty = max(collision_penalty, 8000 - distance * 100)
                        elif distance < 64:  # Moderately close
                            ghost = self.ghosts.get(ghost_id)
                            if ghost and ghost.state == 1:
                                collision_penalty = max(collision_penalty, 3000 - distance * 25)
            
            # Early return for collision cases
            if collision_penalty > 0:
                value = value - collision_penalty
                self.transposition_table[state_key] = value
                return value
            elif collision_penalty < 0:
                value = value + abs(collision_penalty)
                self.transposition_table[state_key] = value
                return value
                
            # No immediate collision - recurse back to maximizer
            next_depth = current_depth + 1
            if next_depth <= max_depth:
                value = self.alpha_beta_min_max(
                    x, y, velX, velY,
                    next_depth, max_depth,
                    alpha, beta, True, weights
                )
                
            self.transposition_table[state_key] = value
            return value
    
    def is_terminal_state(self, x, y):
        """Check if a state is terminal (game over)"""
        # Ghost collision
        for i in range(0, 4):
            ghost = self.ghosts.get(i)
            if ghost and ghost.state == 1:  # Normal ghost
                if self.level.CheckIfHit(x, y, ghost.x, ghost.y, 8):
                    return True
                    
        # All pellets eaten
        if self.level.pellets == 0:
            return True
            
        return False
    
    def detect_oscillation(self):
        """Detect repeated movement patterns"""
        # Need at least 8 moves to detect patterns
        if len(self.move_history) < 8:
            return None
            
        # Check for 2-move oscillation (e.g., LEFT-RIGHT-LEFT-RIGHT)
        last_4 = self.move_history[-4:]
        if last_4[0] == last_4[2] and last_4[1] == last_4[3] and last_4[0] != last_4[1]:
            return {last_4[0], last_4[1]}
            
        # Check for 3-move oscillation (e.g., LEFT-UP-RIGHT-LEFT-UP-RIGHT)
        last_6 = self.move_history[-6:]
        if last_6[0] == last_6[3] and last_6[1] == last_6[4] and last_6[2] == last_6[5]:
            return {last_6[0], last_6[1], last_6[2]}
            
        # Check for positional oscillation
        # If we've been in the same 3 positions repeatedly
        unique_positions = set(self.last_positions)
        if len(unique_positions) <= 3:
            # Identify which directions are causing the oscillation
            oscillating_dirs = set()
            for i in range(1, len(self.move_history)):
                oscillating_dirs.add(self.move_history[-i])
                if len(oscillating_dirs) >= 3:
                    break
            return oscillating_dirs
            
        return None
    
    def calculate_novelty_bonus(self, direction):
        """Calculate bonus for moves rarely taken recently"""
        if not self.move_history:
            return 1.0
            
        # Count occurrences of this direction in recent history
        count = self.move_history.count(direction)
        
        # Bonus for rare directions
        return 1.0 - (count / len(self.move_history))
    
    def update_move_history(self, move):
        """Update the move history with new move"""
        self.move_history.append(move)
        if len(self.move_history) > self.move_history_max:
            self.move_history.pop(0)
            
        # If direction changed, update timer
        if move != self.last_move:
            self.last_direction_change = time.time()
            self.consecutive_same_moves = 0
        else:
            self.consecutive_same_moves += 1
            
        self.last_move = move
    
    def activate_breakout_mode(self):
        """Activate breakout mode to escape repetitive patterns"""
        self.breakout_mode = True
        self.breakout_timer = self.breakout_duration
        self.breakout_target = self.find_breakout_target()
        self.oscillation_counter = 0
        
        # Clear certain cached data to allow fresh decisions
        self.transposition_table = {}
    
    def find_breakout_target(self):
        """Find a suitable target to break out of repetitive movement"""
        # Try to find a different area with pellets
        # Start with power pellets as ideal targets
        for i in range(0, self.level.lvlHeight):
            for j in range(0, self.level.lvlWidth):
                if self.level.GetMapTile(i, j) == 3:  # Power pellet
                    # Convert to pixel coordinates
                    return (j * 16, i * 16)
        
        # If no power pellets, find a distant cluster of regular pellets
        if self.pellet_clusters:
            # Find cluster furthest from current position
            max_distance = 0
            best_cluster = None
            
            for cluster in self.pellet_clusters:
                if cluster:  # Ensure the cluster is not empty
                    # Calculate distance to cluster center
                    center_x = sum(p[1] for p in cluster) / len(cluster)
                    center_y = sum(p[0] for p in cluster) / len(cluster)
                    distance = abs(self.player.x - center_x*16) + abs(self.player.y - center_y*16)
                    
                    if distance > max_distance:
                        max_distance = distance
                        best_cluster = cluster
                        
            if best_cluster:
                # Choose a random pellet from this cluster
                pellet = random.choice(best_cluster)
                return (pellet[1] * 16, pellet[0] * 16)
        
        # Fallback: random unexplored location
        attempts = 0
        while attempts < 10:
            row = random.randint(1, self.level.lvlHeight - 2)
            col = random.randint(1, self.level.lvlWidth - 2)
            
            # Check if tile is walkable and not heavily visited
            if (not self.level.IsWall(row, col) and 
                self.tile_visit_counts.get((row, col), 0) < 3):
                return (col * 16, row * 16)
                
            attempts += 1
        
        # Last resort: random valid position
        return self.find_random_valid_position()
    
    def find_random_valid_position(self):
        """Find a random valid position on the map"""
        valid_positions = []
        
        for i in range(1, self.level.lvlHeight - 1):
            for j in range(1, self.level.lvlWidth - 1):
                if not self.level.IsWall(i, j):
                    valid_positions.append((j * 16, i * 16))
                    
        if valid_positions:
            return random.choice(valid_positions)
        
        # Fallback
        return (self.player.x + 64, self.player.y + 64)
    
    def process_breakout_mode(self):
        """Process movement during breakout mode"""
        if self.breakout_target:
            # Move towards the breakout target
            direction = self.move_towards_target(self.breakout_target[0], self.breakout_target[1])
            
            if direction:
                self.update_move_history(direction)
                return self.apply_move(direction)
        
        # If no valid direction to target, choose randomly
        valid_directions = []
        
        for direction, (velX, velY) in self.directions.items():
            if direction == "STOP":
                continue
                
            # Avoid opposite direction to prevent immediate backtracking
            if direction == self.opposite_moves.get(self.last_move, None):
                continue
                
            if not self.level.CheckIfHitWall(
                self.player.x + velX, 
                self.player.y + velY, 
                self.player.nearestRow, 
                self.player.nearestCol
            ):
                valid_directions.append(direction)
        
        if valid_directions:
            chosen_dir = random.choice(valid_directions)
            self.update_move_history(chosen_dir)
            return self.apply_move(chosen_dir)
        
        # If still no valid direction, just pick any non-wall direction
        for direction, (velX, velY) in self.directions.items():
            if direction == "STOP":
                continue
                
            if not self.level.CheckIfHitWall(
                self.player.x + velX, 
                self.player.y + velY, 
                self.player.nearestRow, 
                self.player.nearestCol
            ):
                self.update_move_history(direction)
                return self.apply_move(direction)
                
        # Last resort: stay still
        return self.apply_move("STOP")
    
    def find_safe_escape_route(self):
        """Find the safest escape route when ghosts are nearby"""
        # Calculate danger level in each direction
        danger_levels = {}
        safe_directions = []
        
        for direction, (velX, velY) in self.directions.items():
            if direction == "STOP":
                continue
                
            # Check if move is valid
            if not self.level.CheckIfHitWall(
                self.player.x + velX, 
                self.player.y + velY, 
                self.player.nearestRow, 
                self.player.nearestCol
            ):
                # Calculate safety of this direction
                new_x = self.player.x + velX
                new_y = self.player.y + velY
                
                danger = 0
                
                # Check danger from each ghost
                for i in range(0, 4):
                    ghost = self.ghosts.get(i)
                    if ghost and ghost.state == 1:  # Normal ghost
                        distance = abs(new_x - ghost.x) + abs(new_y - ghost.y)
                        
                        if distance < 32:
                            danger += 100
                        elif distance < 64:
                            danger += 50
                        elif distance < 96:
                            danger += 20
                        elif distance < 128:
                            danger += 5
                
                # Penalize revisiting tiles
                new_tile = (int((new_y + 8) / 16), int((new_x + 8) / 16))
                visit_count = self.tile_visit_counts.get(new_tile, 0)
                danger += visit_count * 5
                
                # Dead-end check
                if self.is_dead_end(new_tile[0], new_tile[1]):
                    danger += 50
                
                # Check path length in this direction
                path_length = self.calculate_path_length(new_x, new_y, velX, velY)
                if path_length < 3:  # Short path
                    danger += 30
                
                danger_levels[direction] = danger
                
                # Consider safe if danger below threshold
                if danger < 50:
                    safe_directions.append(direction)
        
        # If we have safe directions, choose the safest
        if safe_directions:
            safest_dir = min(safe_directions, key=lambda d: danger_levels[d])
            return safest_dir
            
        # If no safe direction, choose the least dangerous
        if danger_levels:
            return min(danger_levels, key=danger_levels.get)
            
        # No valid directions
        return None
    
    def is_dead_end(self, row, col):
        """Check if a position is a dead end"""
        # Count number of open directions
        open_count = 0
        
        if not self.level.IsWall(row-1, col):
            open_count += 1
        if not self.level.IsWall(row+1, col):
            open_count += 1
        if not self.level.IsWall(row, col-1):
            open_count += 1
        if not self.level.IsWall(row, col+1):
            open_count += 1
            
        # Dead end if only one open direction
        return open_count == 1
    
    def calculate_path_length(self, x, y, velX, velY):
        """Calculate how far Pacman can go in a direction before hitting a wall"""
        length = 0
        cur_x, cur_y = x, y
        
        while True:
            next_x = cur_x + velX
            next_y = cur_y + velY
            
            if self.level.CheckIfHitWall(next_x, next_y, int((cur_y + 8) / 16), int((cur_x + 8) / 16)):
                break
                
            length += 1
            cur_x, cur_y = next_x, next_y
            
            if length >= 20:  # Limit check
                break
                
        return length
    
    def hunt_vulnerable_ghosts(self):
        """Find direction toward nearest vulnerable ghost"""
        nearest_ghost = None
        min_distance = float('inf')
        
        # Find nearest vulnerable ghost
        for i in range(0, 4):
            ghost = self.ghosts.get(i)
            if ghost and ghost.state == 2:  # Vulnerable ghost
                distance = abs(self.player.x - ghost.x) + abs(self.player.y - ghost.y)
                
                if distance < min_distance:
                    min_distance = distance
                    nearest_ghost = ghost
        
        if nearest_ghost:
            # Move toward this ghost
            return self.move_towards_target(nearest_ghost.x, nearest_ghost.y)
            
        return None
    
    def select_next_hunting_target(self):
        """Select next target for hunting mode"""
        # First priority: power pellets
        for i in range(0, self.level.lvlHeight):
            for j in range(0, self.level.lvlWidth):
                if self.level.GetMapTile(i, j) == 3:  # Power pellet
                    # Before targeting, check if path is safe
                    if self.is_path_safe((j*16, i*16)):
                        return (j * 16, i * 16)
        
        # Second priority: pellet clusters
        if self.pellet_clusters:
            # Find the best cluster (balance of size and distance)
            best_score = 0
            best_target = None
            
            for cluster in self.pellet_clusters:
                if not cluster:
                    continue
                    
                # Calculate cluster center
                center_x = sum(p[1] for p in cluster) / len(cluster)
                center_y = sum(p[0] for p in cluster) / len(cluster)
                
                # Convert to pixel coordinates
                center_x_pixel = center_x * 16
                center_y_pixel = center_y * 16
                
                # Calculate distance to cluster
                distance = abs(self.player.x - center_x_pixel) + abs(self.player.y - center_y_pixel)
                
                # Score based on size and distance
                # Prefer larger clusters that are closer
                cluster_score = len(cluster) * 10 - distance * 0.05
                
                # Safety check
                if not self.is_path_safe((center_x_pixel, center_y_pixel)):
                    cluster_score *= 0.5  # Reduce score for unsafe paths
                
                if cluster_score > best_score:
                    best_score = cluster_score
                    best_target = (center_x_pixel, center_y_pixel)
                    
            if best_target:
                return best_target
        
        # Third priority: nearest unvisited pellet
        nearest_pellet = self.find_nearest_unvisited_pellet()
        if nearest_pellet:
            return nearest_pellet
            
        # Last resort: any pellet
        nearest_pellet = self.find_nearest_pellet()
        if nearest_pellet:
            return nearest_pellet
            
        # Fallback: random valid position
        return self.find_random_valid_position()
    
    def find_nearest_unvisited_pellet(self):
        """Find the nearest pellet we haven't visited yet"""
        min_distance = float('inf')
        nearest_pellet = None
        
        for i in range(0, self.level.lvlHeight):
            for j in range(0, self.level.lvlWidth):
                if self.level.GetMapTile(i, j) == 2:  # Regular pellet
                    # Check if we haven't visited this tile
                    if (i, j) not in self.visited_pellets:
                        # Calculate distance
                        distance = abs(self.player.x - j*16) + abs(self.player.y - i*16)
                        
                        if distance < min_distance:
                            min_distance = distance
                            nearest_pellet = (j * 16, i * 16)
        
        return nearest_pellet
    
    def find_nearest_pellet(self):
        """Find the nearest pellet regardless of visit history"""
        min_distance = float('inf')
        nearest_pellet = None
        
        for i in range(0, self.level.lvlHeight):
            for j in range(0, self.level.lvlWidth):
                if self.level.GetMapTile(i, j) == 2 or self.level.GetMapTile(i, j) == 3:
                    # Calculate distance
                    distance = abs(self.player.x - j*16) + abs(self.player.y - i*16)
                    
                    if distance < min_distance:
                        min_distance = distance
                        nearest_pellet = (j * 16, i * 16)
        
        return nearest_pellet
    
    def is_path_safe(self, target):
        """Check if path to target is relatively safe from ghosts"""
        # Simple implementation: check ghost proximity to target
        target_x, target_y = target
        
        for i in range(0, 4):
            ghost = self.ghosts.get(i)
            if ghost and ghost.state == 1:  # Normal ghost
                ghost_distance = abs(target_x - ghost.x) + abs(target_y - ghost.y)
                
                if ghost_distance < 64:  # Ghost too close to target
                    return False
        
        return True
    
    def is_near_target(self, target, threshold=16):
        """Check if we're near a target position"""
        if not target:
            return False
            
        target_x, target_y = target
        distance = abs(self.player.x - target_x) + abs(self.player.y - target_y)
        
        return distance <= threshold
    
    def move_towards_target(self, target_x, target_y):
        """Calculate best direction to move toward target"""
        # Delta to target
        delta_x = target_x - self.player.x
        delta_y = target_y - self.player.y
        
        # Prepare directions in priority order
        directions_to_try = []
        
        # Choose primary direction based on greater distance component
        if abs(delta_x) > abs(delta_y):
            # Horizontal priority
            if delta_x > 0:
                directions_to_try.append("RIGHT")
            else:
                directions_to_try.append("LEFT")
                
            if delta_y > 0:
                directions_to_try.append("DOWN")
            else:
                directions_to_try.append("UP")
        else:
            # Vertical priority
            if delta_y > 0:
                directions_to_try.append("DOWN")
            else:
                directions_to_try.append("UP")
                
            if delta_x > 0:
                directions_to_try.append("RIGHT")
            else:
                directions_to_try.append("LEFT")
        
        # Add remaining directions
        for d in ["RIGHT", "LEFT", "UP", "DOWN"]:
            if d not in directions_to_try:
                directions_to_try.append(d)
                
        # Avoid 180° turns
        if self.last_move in self.opposite_moves and self.opposite_moves[self.last_move] in directions_to_try:
            # Push opposite to end unless it's the only option
            opposite = self.opposite_moves[self.last_move]
            if len(directions_to_try) > 1:
                directions_to_try.remove(opposite)
                directions_to_try.append(opposite)
        
        # Try each direction in priority order
        for direction in directions_to_try:
            velX, velY = self.directions[direction]
            
            # Check if move is valid (no wall)
            if not self.level.CheckIfHitWall(
                self.player.x + velX, 
                self.player.y + velY, 
                self.player.nearestRow, 
                self.player.nearestCol
            ):
                return direction
                
        # No valid move found
        return None
    
    def apply_move(self, direction):
        """Apply the selected move to Pacman"""
        if direction in self.directions:
            velX, velY = self.directions[direction]
            
            # Update Pacman velocity
            self.player.velX = velX
            self.player.velY = velY
            
            return direction
        
        # Fallback
        return "STOP"
    
    def build_maze_map(self):
        """Build a map of the maze for pathfinding"""
        self.maze_map = []
        
        for i in range(self.level.lvlHeight):
            row = []
            for j in range(self.level.lvlWidth):
                # 0 for empty space, 1 for wall
                cell = 1 if self.level.IsWall(i, j) else 0
                row.append(cell)
            self.maze_map.append(row)
    
    def find_pellet_clusters(self):
        """Find clusters of pellets using a simple flood fill"""
        clusters = []
        visited = set()
        
        for i in range(self.level.lvlHeight):
            for j in range(self.level.lvlWidth):
                # Check if this tile has a pellet and hasn't been visited
                if (i, j) not in visited and (
                    self.level.GetMapTile(i, j) == 2 or self.level.GetMapTile(i, j) == 3
                ):
                    # Start a new cluster
                    cluster = []
                    self.flood_fill_pellets(i, j, cluster, visited)
                    
                    if cluster:  # Only add non-empty clusters
                        clusters.append(cluster)
        
        return clusters
    
    def flood_fill_pellets(self, row, col, cluster, visited, depth=0):
        """Recursively find connected pellets"""
        # Check boundaries
        if (row < 0 or row >= self.level.lvlHeight or
            col < 0 or col >= self.level.lvlWidth):
            return
            
        # Check if already visited
        if (row, col) in visited:
            return
            
        # Mark as visited
        visited.add((row, col))
        
        # Check if it's a pellet
        tile = self.level.GetMapTile(row, col)
        if tile == 2 or tile == 3:  # Pellet or power pellet
            cluster.append((row, col))
            
            # Only recurse for first 100 pellets to avoid too large clusters
            if depth < 100:
                # Check adjacent tiles (4-connected)
                self.flood_fill_pellets(row-1, col, cluster, visited, depth+1)
                self.flood_fill_pellets(row+1, col, cluster, visited, depth+1)
                self.flood_fill_pellets(row, col-1, cluster, visited, depth+1)
                self.flood_fill_pellets(row, col+1, cluster, visited, depth+1)
        
        # If it's a wall, don't recurse
        elif tile >= 100 and tile <= 199:  # Wall tile range
            return
        
        # If it's an empty space, check adjacent tiles
        # but with limited depth to avoid huge clusters
        elif depth < 3:  # Limit spread through empty space
            self.flood_fill_pellets(row-1, col, cluster, visited, depth+1)
            self.flood_fill_pellets(row+1, col, cluster, visited, depth+1)
            self.flood_fill_pellets(row, col-1, cluster, visited, depth+1)
            self.flood_fill_pellets(row, col+1, cluster, visited, depth+1)