# game_state_simulator.py
# Modul untuk mensimulasikan state game Pacman tanpa mengubah game yang sebenarnya

class GameStateSimulator:
    def __init__(self, player, level, ghosts, game):
        self.player = player
        self.level = level
        self.ghosts = ghosts
        self.game = game
        
    def simulate_pacman_move(self, x, y, velX, velY, steps=1):
        """
        Simulasikan gerakan Pacman tanpa mengubah state game sebenarnya
        
        Parameters:
        -----------
        x, y : posisi awal Pacman
        velX, velY : kecepatan Pacman
        steps : jumlah langkah yang disimulasikan
        
        Returns:
        --------
        (new_x, new_y, points_gained, hit_ghost, ghost_state)
        """
        new_x = x
        new_y = y
        points_gained = 0
        hit_ghost = False
        ghost_state = 0  # 0: tidak hit, 1: hantu normal, 2: hantu rentan
        
        for _ in range(steps):
            # Cek tabrakan dengan dinding
            nearest_row = int(((new_y + 8) / 16))
            nearest_col = int(((new_x + 8) / 16))
            
            if not self.level.CheckIfHitWall(new_x + velX, new_y + velY, nearest_row, nearest_col):
                # Gerakkan Pacman
                new_x += velX
                new_y += velY
                
                # Cek apa yang dipukul
                nearest_row = int(((new_y + 8) / 16))
                nearest_col = int(((new_x + 8) / 16))
                
                # Cek pelet
                if self.level.GetMapTile(nearest_row, nearest_col) == 2:  # pelet
                    points_gained += 10
                
                # Cek power pelet
                elif self.level.GetMapTile(nearest_row, nearest_col) == 3:  # power pelet
                    points_gained += 50
                
                # Cek tabrakan dengan hantu
                for i in range(0, 4):
                    ghost = self.ghosts.get(i)
                    if ghost:
                        if self.level.CheckIfHit(new_x, new_y, ghost.x, ghost.y, 8):
                            hit_ghost = True
                            
                            if ghost.state == 1:  # hantu normal
                                ghost_state = 1
                            elif ghost.state == 2:  # hantu rentan
                                ghost_state = 2
                                points_gained += self.game.ghostValue
            else:
                # Tidak bisa bergerak, ada dinding
                break
                
        return (new_x, new_y, points_gained, hit_ghost, ghost_state)
    
    def simulate_ghost_paths(self, pacman_x, pacman_y, time_steps=10):
        """
        Memprediksi jalur yang akan diambil hantu berdasarkan posisi pacman
        
        Returns:
        --------
        Dictionary berisi prediksi posisi hantu dalam beberapa langkah ke depan
        """
        ghost_paths = {}
        
        for i in range(0, 4):
            ghost = self.ghosts.get(i)
            if not ghost:
                continue
                
            if ghost.state == 3:  # Jika hantu dalam keadaan "spectacles", lewati
                continue
                
            # Simpan posisi sekarang
            ghost_paths[i] = [(ghost.x, ghost.y)]
            
            # Prediksikan posisi selanjutnya (sangat sederhana)
            # Dalam implementasi lengkap, Anda dapat menggunakan A* pathfinding untuk memprediksi
            cur_x, cur_y = ghost.x, ghost.y
            
            if ghost.state == 1:  # Hantu normal (mengejar)
                for _ in range(time_steps):
                    # Gerakan sederhana ke arah pacman
                    dx = 0
                    dy = 0
                    
                    if pacman_x > cur_x:
                        dx = ghost.speed
                    elif pacman_x < cur_x:
                        dx = -ghost.speed
                        
                    if pacman_y > cur_y:
                        dy = ghost.speed
                    elif pacman_y < cur_y:
                        dy = -ghost.speed
                    
                    # Pilih arah dengan prioritas (horizontal atau vertikal)
                    if abs(pacman_x - cur_x) > abs(pacman_y - cur_y):
                        # Prioritas horizontal
                        if not self.level.CheckIfHitWall(cur_x + dx, cur_y, int((cur_y + 8) / 16), int((cur_x + 8) / 16)):
                            cur_x += dx
                        elif not self.level.CheckIfHitWall(cur_x, cur_y + dy, int((cur_y + 8) / 16), int((cur_x + 8) / 16)):
                            cur_y += dy
                    else:
                        # Prioritas vertikal
                        if not self.level.CheckIfHitWall(cur_x, cur_y + dy, int((cur_y + 8) / 16), int((cur_x + 8) / 16)):
                            cur_y += dy
                        elif not self.level.CheckIfHitWall(cur_x + dx, cur_y, int((cur_y + 8) / 16), int((cur_x + 8) / 16)):
                            cur_x += dx
                    
                    ghost_paths[i].append((cur_x, cur_y))
            elif ghost.state == 2:  # Hantu rentan (melarikan diri)
                for _ in range(time_steps):
                    # Gerakan sederhana menjauh dari pacman
                    dx = 0
                    dy = 0
                    
                    if pacman_x > cur_x:
                        dx = -ghost.speed
                    elif pacman_x < cur_x:
                        dx = ghost.speed
                        
                    if pacman_y > cur_y:
                        dy = -ghost.speed
                    elif pacman_y < cur_y:
                        dy = ghost.speed
                    
                    # Pilih arah dengan prioritas (horizontal atau vertikal)
                    if abs(pacman_x - cur_x) > abs(pacman_y - cur_y):
                        # Prioritas horizontal
                        if not self.level.CheckIfHitWall(cur_x + dx, cur_y, int((cur_y + 8) / 16), int((cur_x + 8) / 16)):
                            cur_x += dx
                        elif not self.level.CheckIfHitWall(cur_x, cur_y + dy, int((cur_y + 8) / 16), int((cur_x + 8) / 16)):
                            cur_y += dy
                    else:
                        # Prioritas vertikal
                        if not self.level.CheckIfHitWall(cur_x, cur_y + dy, int((cur_y + 8) / 16), int((cur_x + 8) / 16)):
                            cur_y += dy
                        elif not self.level.CheckIfHitWall(cur_x + dx, cur_y, int((cur_y + 8) / 16), int((cur_x + 8) / 16)):
                            cur_x += dx
                    
                    ghost_paths[i].append((cur_x, cur_y))
                
        return ghost_paths
    
    def is_safe_path(self, pacman_x, pacman_y, velX, velY, steps=10):
        """
        Memeriksa apakah jalur yang diambil Pacman aman dari hantu
        
        Returns:
        --------
        (is_safe, danger_level)
        is_safe: Boolean, True jika jalur aman
        danger_level: 0-10, tingkat bahaya jalur (0 paling aman)
        """
        # Simulasikan gerakan Pacman
        pacman_path = []
        cur_x, cur_y = pacman_x, pacman_y
        
        for _ in range(steps):
            if not self.level.CheckIfHitWall(cur_x + velX, cur_y + velY, int((cur_y + 8) / 16), int((cur_x + 8) / 16)):
                cur_x += velX
                cur_y += velY
                pacman_path.append((cur_x, cur_y))
            else:
                break
        
        # Prediksi jalur hantu
        ghost_paths = self.simulate_ghost_paths(pacman_x, pacman_y, steps)
        
        # Cek tabrakan
        danger_level = 0
        is_safe = True
        
        for step in range(min(len(pacman_path), steps)):
            pacman_pos = pacman_path[step]
            
            for ghost_id, path in ghost_paths.items():
                if step < len(path):
                    ghost_pos = path[step]
                    
                    # Hitung jarak
                    distance = abs(pacman_pos[0] - ghost_pos[0]) + abs(pacman_pos[1] - ghost_pos[1])
                    
                    if distance < 16:  # Tabrakan
                        ghost = self.ghosts.get(ghost_id)
                        if ghost and ghost.state == 1:  # Hantu normal
                            is_safe = False
                            danger_level = 10
                            return (is_safe, danger_level)
                    elif distance < 32:  # Dekat
                        ghost = self.ghosts.get(ghost_id)
                        if ghost and ghost.state == 1:  # Hantu normal
                            danger_level = max(danger_level, 10 - int(distance / 3))
                    elif distance < 64:  # Agak dekat
                        ghost = self.ghosts.get(ghost_id)
                        if ghost and ghost.state == 1:  # Hantu normal
                            danger_level = max(danger_level, 5 - int(distance / 12))
        
        if danger_level >= 7:
            is_safe = False
            
        return (is_safe, danger_level)
    
    def estimate_survival_probability(self, pacman_x, pacman_y, velX, velY, max_steps=50):
        """
        Estimasi kemungkinan bertahan hidup dengan strategi saat ini
        
        Returns:
        --------
        probability: 0.0-1.0, kemungkinan bertahan hidup
        """
        # Implementasi sederhana
        is_safe, danger_level = self.is_safe_path(pacman_x, pacman_y, velX, velY, 10)
        
        if not is_safe:
            # Jalur sangat berbahaya
            return 0.1
        elif danger_level >= 5:
            # Jalur cukup berbahaya
            return 0.5
        else:
            # Jalur relatif aman
            return 0.9
    
    def count_accessible_pellets(self, pacman_x, pacman_y, radius=5):
        """
        Hitung jumlah pelet yang dapat diakses dalam radius tertentu
        
        Returns:
        --------
        pellet_count: jumlah pelet yang dapat diakses
        """
        pellet_count = 0
        row = int((pacman_y + 8) / 16)
        col = int((pacman_x + 8) / 16)
        
        for i in range(row-radius, row+radius+1):
            for j in range(col-radius, col+radius+1):
                if i >= 0 and i < self.level.lvlHeight and j >= 0 and j < self.level.lvlWidth:
                    if self.level.GetMapTile(i, j) == 2:  # Pelet
                        # Cek apakah bisa mencapai pelet ini tanpa menabrak dinding
                        # Sederhana: jika Manhattan distance <= radius, kita anggap bisa diakses
                        if abs(i - row) + abs(j - col) <= radius:
                            pellet_count += 1
        
        return pellet_count
    
    def find_safe_direction(self, pacman_x, pacman_y):
        """
        Temukan arah gerakan teraman jika ada bahaya
        
        Returns:
        --------
        (velX, velY): kecepatan yang disarankan
        """
        directions = [
            (self.player.speed, 0),    # Kanan
            (-self.player.speed, 0),   # Kiri
            (0, self.player.speed),    # Bawah
            (0, -self.player.speed)    # Atas
        ]
        
        best_direction = (0, 0)
        best_safety = -1
        
        for velX, velY in directions:
            # Cek apakah bisa bergerak ke arah ini
            if not self.level.CheckIfHitWall(pacman_x + velX, pacman_y + velY, int((pacman_y + 8) / 16), int((pacman_x + 8) / 16)):
                # Simulasikan keamanan jalur
                is_safe, danger_level = self.is_safe_path(pacman_x, pacman_y, velX, velY, 5)
                safety_score = 10 - danger_level
                
                if safety_score > best_safety:
                    best_safety = safety_score
                    best_direction = (velX, velY)
        
        return best_direction