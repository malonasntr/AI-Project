import math

class ExpectimaxAgent:
    def __init__(self, depth=2):
        self.depth = depth
        self.pellet_id = None
        self.power_pellet_id = None
        
    def initialize_tile_ids(self, tileID):
        """Initialize tile IDs from the global tileID dictionary"""
        self.pellet_id = tileID['pellet']
        self.power_pellet_id = tileID['pellet-power']
        
    def get_action(self, game_state, player, level, ghosts):
        # Make sure tile IDs are initialized
        if self.pellet_id is None:
            raise RuntimeError("Tile IDs not initialized. Call initialize_tile_ids first.")
            
        legal_moves = self.get_legal_moves(game_state, player, level)
        if not legal_moves:
            return (0, 0)
            
        max_value = float('-inf')
        best_action = legal_moves[0]
        
        for action in legal_moves:
            value = self.value(game_state, action, player, level, ghosts, 0)
            if value > max_value:
                max_value = value
                best_action = action
                
        return best_action
        
    def value(self, state, action, player, level, ghosts, depth):
        if depth == self.depth:
            return self.evaluate_state(state, player, level, ghosts)
            
        return self.max_value(state, action, player, level, ghosts, depth)
        
    def max_value(self, state, action, player, level, ghosts, depth):
        next_x = player.x + action[0]
        next_y = player.y + action[1]
        
        if level.CheckIfHitWall(next_x, next_y, player.nearestRow, player.nearestCol):
            return float('-inf')
            
        score = self.evaluate_state((next_x, next_y), player, level, ghosts)
        legal_moves = self.get_legal_moves((next_x, next_y), player, level)
        
        if not legal_moves:
            return score
            
        max_value = float('-inf')
        for next_action in legal_moves:
            value = self.value((next_x, next_y), next_action, player, level, ghosts, depth + 1)
            max_value = max(max_value, value)
            
        return score + max_value * 0.8  # Discount future rewards
        
    def get_legal_moves(self, state, player, level):
        moves = []
        speed = player.speed
        directions = [(speed, 0), (-speed, 0), (0, speed), (0, -speed)]
        
        x, y = state if isinstance(state, tuple) else (player.x, player.y)
        
        for dx, dy in directions:
            if not level.CheckIfHitWall(x + dx, y + dy, int((y + 8) / 16), int((x + 8) / 16)):
                moves.append((dx, dy))
                
        return moves
        
    def evaluate_state(self, state, player, level, ghosts):
        x, y = state if isinstance(state, tuple) else (player.x, player.y)
        row = int((y + 8) / 16)
        col = int((x + 8) / 16)
        
        score = 0
        
        # Reward for pellets
        if level.GetMapTile(row, col) == self.pellet_id:
            score += 10
        elif level.GetMapTile(row, col) == self.power_pellet_id:
            score += 50
            
        # Penalty for being close to ghosts
        for i in range(4):  # Only consider the first 4 ghosts (not the blue/white ones)
            ghost = ghosts[i]
            ghost_dist = math.sqrt((x - ghost.x)**2 + (y - ghost.y)**2)
            if ghost.state == 1:  # Normal ghost
                if ghost_dist < 80:
                    score -= (80 - ghost_dist) * 2
            elif ghost.state == 2:  # Vulnerable ghost
                if ghost_dist < 120:
                    score += (120 - ghost_dist)
                    
        return score
