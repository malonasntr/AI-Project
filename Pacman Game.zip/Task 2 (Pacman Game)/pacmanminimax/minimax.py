
import copy
import math

# === GameState class ===

class GameState:
    def __init__(self, pacman_pos, ghost_positions, pellet_map, score):
        self.pacman_pos = pacman_pos
        self.ghost_positions = ghost_positions
        self.pellet_map = pellet_map  # 2D grid (list of list), True = pellet
        self.score = score

    def get_legal_actions(self, agent_index):
        directions = ['UP', 'DOWN', 'LEFT', 'RIGHT']
        x, y = self.pacman_pos if agent_index == 0 else self.ghost_positions[agent_index - 1]
        legal_actions = []

        for d in directions:
            nx, ny = move_in_direction(x, y, d)
            if is_valid_position(nx, ny):
                legal_actions.append(d)
        return legal_actions

    def generate_successor(self, agent_index, action):
        new_state = copy.deepcopy(self)

        if agent_index == 0:  # Pacman
            new_state.pacman_pos = move_in_direction(*self.pacman_pos, action)
            px, py = new_state.pacman_pos
            if new_state.pellet_map[py][px]:
                new_state.pellet_map[py][px] = False
                new_state.score += 10
        else:  # Ghosts
            ghost_index = agent_index - 1
            new_state.ghost_positions[ghost_index] = move_in_direction(*self.ghost_positions[ghost_index], action)

        return new_state

    def is_win(self):
        return not any(any(row) for row in self.pellet_map)

    def is_lose(self):
        return self.pacman_pos in self.ghost_positions


# === Helper Functions ===

def move_in_direction(x, y, direction):
    if direction == 'UP':
        return (x, y - 1)
    elif direction == 'DOWN':
        return (x, y + 1)
    elif direction == 'LEFT':
        return (x - 1, y)
    elif direction == 'RIGHT':
        return (x + 1, y)
    return (x, y)

def is_valid_position(x, y):
    # Replace this with your actual wall-checking logic
    return 0 <= x < MAP_WIDTH and 0 <= y < MAP_HEIGHT and not WALL_GRID[y][x]

def manhattan(pos1, pos2):
    return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1])

def manhattan_distance_to_nearest_pellet(pacman_pos, pellet_map):
    min_dist = float('inf')
    for y, row in enumerate(pellet_map):
        for x, has_pellet in enumerate(row):
            if has_pellet:
                dist = manhattan(pacman_pos, (x, y))
                if dist < min_dist:
                    min_dist = dist
    return min_dist if min_dist != float('inf') else 0

def count_remaining_pellets(pellet_map):
    return sum(row.count(True) for row in pellet_map)

# === Evaluation Function ===

def evaluate_state(state: GameState):
    if state.is_win():
        return 99999
    if state.is_lose():
        return -99999

    ghost_dists = [manhattan(state.pacman_pos, g) for g in state.ghost_positions]
    nearest_ghost_dist = min(ghost_dists) if ghost_dists else 1
    pellet_dist = manhattan_distance_to_nearest_pellet(state.pacman_pos, state.pellet_map)
    pellet_count = count_remaining_pellets(state.pellet_map)

    return (
        -2 * pellet_dist +
        5 * nearest_ghost_dist -
        20 * pellet_count +
        state.score
    )

# === Minimax Algorithm ===

def minimax(state: GameState, depth, agent_index, max_depth):
    if depth == max_depth or state.is_win() or state.is_lose():
        return evaluate_state(state), None

    num_agents = 1 + len(state.ghost_positions)
    next_agent = (agent_index + 1) % num_agents
    next_depth = depth + 1 if next_agent == 0 else depth

    actions = state.get_legal_actions(agent_index)
    if not actions:
        return evaluate_state(state), None

    if agent_index == 0:  # Pacman
        best_value = -math.inf
        best_action = None
        for action in actions:
            successor = state.generate_successor(agent_index, action)
            value, _ = minimax(successor, next_depth, next_agent, max_depth)
            if value > best_value:
                best_value = value
                best_action = action
        return best_value, best_action
    else:  # Ghosts
        best_value = math.inf
        best_action = None
        for action in actions:
            successor = state.generate_successor(agent_index, action)
            value, _ = minimax(successor, next_depth, next_agent, max_depth)
            if value < best_value:
                best_value = value
                best_action = action
        return best_value, best_action
